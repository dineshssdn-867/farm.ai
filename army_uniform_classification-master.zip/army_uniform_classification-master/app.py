
import os
import cv2
import numpy as np
import urllib.request
from flask import (
    Flask,
    render_template,
    request,
    redirect,
    flash,
    url_for,
    render_template_string,
    send_file,
    jsonify,
)
from main_image import getPrediction
from werkzeug.utils import secure_filename
from utils import html_js_file

app = Flask(__name__)

@app.route("/")
@app.route("/home")
def home():
    return render_template("index.html")


@app.route("/army_detect_form", methods=["GET", "POST"])
def army_detect_form():
    return render_template("predict.html", predicted=False)

@app.route("/army_detect_camera", methods=["GET", "POST"])
def army_detect_camera():
    return render_template_string(html_js_file)

@app.route("/predict_army_detect_image", methods=["POST"])
def predict_army_detect_image():
    if request.method == "POST":
        file = request.files.get("image")
        if file is not None:
            nparr = np.fromstring(request.files["image"].read(), np.uint8)
            img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            res = getPrediction(img)
            return render_template(
                "predict.html",
                predicted=True,
                filename=res
            )
        else:
            return render_template("predict.html", predicted=False)


if __name__ == "__main__":
  app.run(debug=True)
