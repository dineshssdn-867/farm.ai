import string
import random
from ultralytics import YOLO
from utils import save_image_frame

model = YOLO('best_pretrained_model.pt')

def getPrediction(image):
    results = model.predict(image, conf=0.5)
    annotated_frame = results[0].plot()
    res = ''.join(random.choices(string.ascii_uppercase + string.digits, k=7))
    filename = save_image_frame(annotated_frame, res)
    return filename
